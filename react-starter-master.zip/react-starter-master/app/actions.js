var Actions = require("items-store/Actions");

// All the actions of the application

exports.Todo = Actions.create([
	"add",
	"update",
	"reload"
]);
